/* SPDX-License-Identifier: GPL-2.0-or-later */

#include "70f_universal.h"
//LED共正极

void keyboard_pre_init_user(void) {
  // Call the keyboard pre init code.       //Setting status LEDs pins to output and -5V (off)

  // Set our LED pins as output
  setPinOutput(C14);
 // setPinOutput(B4);
 // setPinOutput(B15);
}

bool led_update_kb(led_t led_state) {
    if(led_update_user(led_state)) { 
        writePin(C14, !led_state.caps_lock);
      //  writePin(B4, !led_state.num_lock);
    }
    return true;
}



#ifdef RGB_MATRIX_ENABLE
led_config_t g_led_config = {{    //通过使用按键的电子矩阵行和列告诉系统此 LED 代表什么按键
    //      C0,     C1,     C2,      C3,     C4      C5      C6      C7       C8        C9     C10       C11     C12     C13     C14,    C15,     C16,      C17,       C18     
    {        0,      1,      2,       3,      4,      5,      6,      7,       8,       9,     10,       11,     12,     13,     14,      15,      16,       17,   },  //19
    {       35,     34,     33,      32,     31,     30,     29,     28,      27,      26,     25,       24,     23,     22,     21,      20,      19,       18,   },  //18
    {       36,     37,     38,      39,     40,     41,     42,     43,      44,      45,     46,       47,     48,     49,     50,  NO_LED,  NO_LED,   NO_LED,   },  //17 
    {       68,     67,     66,      65,     64,     63,     62,     61,      60,      59,     58,       57,     56,     55,     54,      53,      52,       51,   },    //17
    {       69,    70,      71,      72, NO_LED,     73, NO_LED, NO_LED,      74,      75, NO_LED,       76,     77,     78,     79,      80,      81,       82    },  //4
   
}, {   //C0           C1          C2         C3         C4          C5         C6          C7          C8          C9             C10            C11         C12            C13            c14,            C15          C16            C17          C18
       //LED Index to Physical Position   //在键盘上的物理位置   
    { 0,  0 }, { 14,  0 }, { 28,  0 }, { 42,  0 }, { 56,  0 }, { 70,  0 }, { 84,  0 }, { 98,  0 },  { 112,  0 },  { 126,  0 },   { 140,  0 },  { 154,  0 },  { 168,  0 },  { 182,  0 },  { 196,  0 },  { 210,  0 },  { 224,  0 },  { 238,  0 },
    { 0, 16 }, { 14, 16 }, { 28, 16 }, { 42, 16 }, { 56, 16 }, { 70, 16 }, { 84, 16 }, { 98, 16 },  { 112, 16 },  { 126, 16 },   { 140, 16 },  { 154, 16 },  { 168, 16 },  { 182, 16 },  { 196, 16 },  { 210,  16},  { 224, 16 },  { 238, 16 },
    { 0, 32 }, { 14, 32 }, { 28, 32 }, { 42, 32 }, { 56, 32 }, { 70, 32 }, { 84, 32 }, { 98, 32 },  { 112, 32 },  { 126, 32 },   { 140, 32 },  { 154, 32 },  { 168, 32 },  { 182, 32 },  { 196, 32 }, 
    { 0, 48 }, { 14, 48 }, { 28, 48 }, { 42, 48 }, { 56, 48 }, { 70, 48 }, { 84, 48 }, { 98, 48 },  { 112, 48 },  { 126, 48 },   { 140, 48 },  { 154, 48 },  { 168, 48 },  { 182, 48 },  { 196, 48 },  { 210, 48 },  { 224, 48 },  { 238, 48 },
    { 0, 64 }, { 14, 64 }, { 28, 64 }, { 42, 64 },             { 70, 64 },                          { 112, 64 },  { 126, 64 },                 { 154, 64 },  { 168, 64 },  { 182, 64 },  { 196, 64 },  { 210, 64 },  { 224, 64 },  { 238, 64 }
                                                                                                                                
  }, {
  //0  1  2  3  4  5  6  7  8  9  10 11 12 13 14  15 16 17 18  
    1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4, 4, 4,  1,
    1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4, 4, 4,  1,
    1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4,
    1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4, 4, 4,  1,
    1, 4, 4, 4,    4,       4, 4,    4, 4,  4, 4, 4, 4,  1,
}
};
#endif












/*
#ifdef RGB_MATRIX_ENABLE
led_config_t g_led_config = { {
    // Key Matrix to LED Index
	// 0        1         2         3        4       5        6        7       8         9         10        11        12       13        14         
    {  NO_LED,  NO_LED,   NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,   NO_LED,   NO_LED,   NO_LED,  NO_LED,    NO_LED,   },
    {  NO_LED,  NO_LED,   NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,   NO_LED,   NO_LED,   NO_LED,  NO_LED,    NO_LED,   },
    {  NO_LED,  NO_LED,   NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,   NO_LED,   NO_LED,   NO_LED,  NO_LED,    NO_LED,   },
    {       0,       1,        2,      3 ,       4,       5,       6,       7,       8,       9,       10,       11,       12,  NO_LED,    13,          },
    {  NO_LED,  NO_LED,   NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,   NO_LED,   NO_LED,   NO_LED,  NO_LED,    NO_LED,   },
    {  NO_LED,  NO_LED,   NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,   NO_LED,   NO_LED,   NO_LED,  NO_LED,    NO_LED,   },
	{  NO_LED,  NO_LED,   NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,  NO_LED,   NO_LED,   NO_LED,   NO_LED,  NO_LED,    NO_LED,   },
}, { 
    // LED Index to Physical Position
   
    { 0, 36 }, { 15, 36 }, { 30, 36 }, { 45, 36 }, { 60, 36 }, { 75, 36 }, { 90, 36 }, { 105, 36 }, { 120, 36 }, { 135, 36 }, { 150, 36 }, { 165, 36 }, { 180, 36 }, { 195, 36 },   
  }, {
    // LED Index to Flag
	//  0  1  2  3  4  5  6  7  8  9 10  11  12 13, 14  
        1,    4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4,    1,
   } };
#endif
*/


/*
#ifdef RGB_MATRIX_ENABLE
led_config_t g_led_config = { {
    // Key Matrix to LED Index
	// 0        1  2       3        4        5   6       7       8       9       10  11  12  13           14       15       16    
    {  0, NO_LED,  1,      2,       3,       4,  5,      6,      7,      8,       9, 10, 11, 12,          13,      14,      15 },
    { 32,     31, 30,     29,      28,      27, 26,     25,     24,     23,      22, 21, 20, 19,          18,      17,      16 },
    { 33,     34, 35,     36,      37,      38, 39,     40,     41,     42,      43, 44, 45, 46,          47,      48,      49 },
    { 63,     62, 61,     60,      59,      58, 57,     56,     55,     54,      53, 52, 51, 50,      NO_LED,  NO_LED,  NO_LED },
    { 64,NO_LED,  65,     66,      67,      68, 69,     70,     71,     72,      73, 74, 75, NO_LED,  NO_LED,      76,  NO_LED },
    { 86,    85,  84, NO_LED,  NO_LED,  NO_LED, 83, NO_LED, NO_LED, NO_LED,  NO_LED, 82, 81, 80,          79,      78,      77 },
}, {
    // LED Index to Physical Position
    { 0,  0 },             { 30,  0 }, { 45,  0 }, { 60,  0 }, { 75,  0 }, { 90,  0 }, { 105,  0 }, { 120,  0 }, { 135, 0 },  { 150,  0 }, { 165,  0 }, { 180,  0 }, { 195,  0 },   { 210,  0 }, { 225,  0 }, { 240,   0 },  
    { 0, 12 }, { 15, 12 }, { 30, 12 }, { 45, 12 }, { 60, 12 }, { 75, 12 }, { 90, 12 }, { 105, 12 }, { 120, 12 }, { 135, 12 }, { 150, 12 }, { 165, 12 }, { 180, 12 }, { 195, 12 },   { 210, 12 }, { 225, 12 }, { 240,  12 },   
    { 0, 24 }, { 15, 24 }, { 30, 24 }, { 45, 24 }, { 60, 24 }, { 75, 24 }, { 90, 24 }, { 105, 24 }, { 120, 24 }, { 135, 24 }, { 150, 24 }, { 165, 24 }, { 180, 24 }, { 195, 24 },   { 210, 24 }, { 225, 24 }, { 240,  24 },   
    { 0, 36 }, { 15, 36 }, { 30, 36 }, { 45, 36 }, { 60, 36 }, { 75, 36 }, { 90, 36 }, { 105, 36 }, { 120, 36 }, { 135, 36 }, { 150, 36 }, { 165, 36 }, { 180, 36 }, { 195, 36 },   
    { 0, 48 },             { 30, 48 }, { 45, 48 }, { 60, 48 }, { 75, 48 }, { 90, 48 }, { 105, 48 }, { 120, 48 }, { 135, 48 }, { 150, 48 }, { 165, 48 }, { 180, 48 },                             { 225, 48 },                
    { 0, 64 }, { 15, 64 }, { 30, 64 },                                     { 90, 64 },                                                     { 180, 64 }, { 180, 64 }, { 195, 64 },   { 210, 64 }, { 225, 64 }, { 240, 64 },    
    }, {
    // LED Index to Flag
	//  0 |1  2  3  4  5  6  7  8  9 10  11  12 13, 14  15, 16
        1,    4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4,  4, 4,  4,   1,   //16
        1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4,  4, 4,  4,   1,   //17
		1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4,  4, 4,  4,   1,   //17
        1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4,  4,               //14
		1,    4, 4, 4, 4, 4, 4, 4, 4, 4,  4, 4,         4,        // 13
        1, 1, 1,          1,              1, 1,  1, 1,  1,   1,   // 10
} };
#endif
*/
/*
const uint8_t music_map[MATRIX_ROWS][MATRIX_COLS] = LAYOUT(
	 92, 93, 94, 95, 96, 97, 98, 99,100,101,102,103, 104,105,106,107,
	 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91,
	 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 
	 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 
	 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 
	 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,   
	  0,  1,  2,  3, 4,  5,  6,  7,  8,   9, 10, 11, 12, 13, 14 
);
*/
/*
//LED共负极
void keyboard_pre_init_user(void) {
  // Call the keyboard pre init code.

  // Set our LED pins as output
  setPinOutput(C15);
  setPinOutput(A10);
  setPinOutput(A9);
 // setPinOutput(D1);
}

void led_set_user(uint8_t usb_led) {
    if (IS_LED_ON(usb_led, USB_LED_NUM_LOCK)) {
        writePinHigh(C15);
    } else {
        writePinLow(C15);
    }
    
    if (IS_LED_ON(usb_led, USB_LED_CAPS_LOCK)) {
        writePinHigh(A10);
    } else {
        writePinLow(A10);
    }
    if (IS_LED_ON(usb_led, USB_LED_SCROLL_LOCK)) {
        writePinHigh(A9);
    } else {
        writePinLow(A9);
    }
    
}
*/
