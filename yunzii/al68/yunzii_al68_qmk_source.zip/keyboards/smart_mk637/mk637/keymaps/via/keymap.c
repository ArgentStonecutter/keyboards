/* 
Copyright 2021 owlab
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include QMK_KEYBOARD_H
#include "common.h"

#ifdef ENCODER_MAP_ENABLE
const uint16_t PROGMEM encoder_map[][NUM_ENCODERS][2] = {
    [0] =  { ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  },
    [1] =  { ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  },
	[2] =  { ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  },
	[3] =  { ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  },
    [4] =  { ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  },
    [5] =  { ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  },
	[6] =  { ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  },
	[7] =  { ENCODER_CCW_CW(KC_VOLD, KC_VOLU)  }

};
#endif

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {


	// [0] = LAYOUT(
	// 	KC_ESC,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0,  	KC_MINS,  	KC_EQL,  	KC_BSPC,  ENC_TG,
	// 	KC_TAB,  KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P,    	KC_LBRC, 	KC_RBRC, 	KC_BSLS,KC_DELETE,
	// 	KC_CAPS, KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN, 	KC_QUOT,    KC_ENT,     KC_PAGE_UP,
	// 	KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    KC_COMM, KC_DOT,  KC_SLSH, 	KC_RSFT,    KC_UP,   KC_PAGE_DOWN,
	// 	KC_LCTL, KC_LGUI,         KC_LALT,   KC_SPC,                   MO(1),   KC_RCTL,          KC_LEFT, 	KC_DOWN,	KC_RIGHT  , _______ 
	// ),
	// [1] = LAYOUT(
	// 	KC_GRV,	 KC_BRID,   KC_BRIU, LGUI(KC_TAB), 	KC_MYCM, 	KC_MAIL,   KC_WHOM, 	KC_MPRV, 	KC_MPLY, KC_MNXT,   KC_MUTE, 	KC_VOLD, 	 KC_VOLU  ,	KC_BAT, _______,
	// 	_______, KC_BLE1, KC_BLE2, 	KC_BLE3,KC_24G,  _______, _______, 	_______, _______, _______, 	_______, 	_______, 	_______, 	RGB_HUI,     KC_RESET,
	// 	_______, 	KC_MACMODE, 	_______, 	_______, 	_______, 	_______,	_______, 	_______, 	_______, _______, 	_______, 	_______, 	RGB_MOD,   _______, 
	// 	_______, 	_______, 	_______,  	KC_MODEPLUS,   KC_HUEPLS,	  _______, 	_______, 	_______, 	_______, 	_______, 	_______,    _______,   RGB_VAI,  _______,
	// 	_______, 	KC_WIN, 	_______,					KC_SHUTRGB,    	                      _______, 	_______,	RGB_SPD,	RGB_VAD, RGB_SPI  , _______
	// ),
	// [2] = LAYOUT(
	// 	KC_ESC,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0,  	KC_MINS,  	KC_EQL,  	KC_BSPC, ENC_TG,
	// 	KC_TAB,  KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P,    	KC_LBRC, 	KC_RBRC, 	KC_BSLS,KC_DELETE,
	// 	KC_CAPS, KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN, 	KC_QUOT,    KC_ENT,     KC_PAGE_UP,
	// 	KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    KC_COMM, KC_DOT,  KC_SLSH, 	KC_RSFT,    KC_UP,   KC_PAGE_DOWN,
	// 	KC_LCTL, KC_LALT,         KC_LGUI,   KC_SPC,                   MO(3),   KC_RCTL,          KC_LEFT, 	KC_DOWN,	KC_RIGHT    , _______
	// ),
	// [3] = LAYOUT(
	// 	KC_GRV,	 KC_BRIU,   KC_BRID, 	KC_Mctl, 	KC_Lpad, 	 _______,   _______, 	KC_MPRV, 	KC_MPLY, KC_MNXT,  KC_MUTE, 	KC_VOLD, 	 KC_VOLU  ,	KC_BAT,  _______,
	// 	_______,	KC_BLE1,	KC_BLE2, 	KC_BLE3, 	KC_24G, 	_______, 	_______, 	_______, 	_______, _______, 	_______, 	_______, 	_______, 	RGB_HUI,  KC_RESET,
	// 	_______, 	_______, 	KC_WINMODE, 	_______, 	_______, 	_______,	_______, 	_______, 	_______, _______, 	_______, 	_______, 	RGB_MOD,   _______, 
	//     _______, 	_______, 	_______,  	KC_MODEPLUS,   KC_HUEPLS,	  _______, 	_______, 	_______, 	_______, 	_______, 	_______,    _______,   RGB_VAI,   _______,
	// 	_______, 	_______, 	_______,					KC_SHUTRGB,    	                      _______, 	_______,	RGB_SPD,	RGB_VAD, RGB_SPI  , _______
	// )



	[0] = LAYOUT(
	KC_ESC,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0,  	KC_MINS,  	KC_EQL,  	KC_BSPC,  KC_MUTE,
	KC_TAB,  KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P,    	KC_LBRC, 	KC_RBRC, 	KC_BSLS,KC_DELETE,
	KC_CAPS, KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN, 	KC_QUOT,    KC_ENT,     KC_PAGE_UP,
	KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    KC_COMM, KC_DOT,  KC_SLSH, 	KC_RSFT,    KC_UP,   KC_PAGE_DOWN,
	KC_LCTL, KC_LGUI,          KC_LALT,   KC_SPC,                  MO(1),   KC_RCTL,          KC_LEFT, 	KC_DOWN,	KC_RIGHT  , _______ 
	),
	[1] = LAYOUT(
		KC_GRV,	 KC_BRID,   KC_BRIU, LGUI(KC_TAB), 	KC_MYCM, 	KC_MAIL,   KC_WHOM, 	KC_MPRV, 	KC_MPLY, KC_MNXT,   KC_MUTE, 	KC_VOLD, 	 KC_VOLU  ,	KC_SHUTRGB, KC_MUTE,
		_______, KC_BLE1, KC_BLE2, 	KC_BLE3,KC_24G,  _______, _______, 	_______, _______, _______, 	_______, 	_______, 	_______, 	RGB_MOD,     _______,
		_______, 	KC_MACMODE, 	_______, 	_______, 	_______, 	_______,	_______, 	_______, 	_______, KC_LOCK, 	_______, 	_______, 	RGB_HUI,   KC_VAL_UP, 
		_______, 	_______, 	_______,  	_______,   _______,	  _______, 	_______, 	_______, 	_______, 	_______, 	_______,    _______,   RGB_VAI,  KC_VAL_DN,
		_______, 	KC_WIN, 	_______,					KC_RESET,    	                      _______, 	KC_BAT,	RGB_SPD,	RGB_VAD, RGB_SPI  , _______
	),
	[2] = LAYOUT(
		KC_ESC,  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0,  	KC_MINS,  	KC_EQL,  	KC_BSPC, KC_MUTE,
		KC_TAB,  KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P,    	KC_LBRC, 	KC_RBRC, 	KC_BSLS,KC_DELETE,
		KC_CAPS, KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN, 	KC_QUOT,    KC_ENT,     KC_PAGE_UP,
		KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    KC_COMM, KC_DOT,  KC_SLSH, 	KC_RSFT,    KC_UP,   KC_PAGE_DOWN,
		KC_LCTL, KC_LALT,          KC_LGUI,   KC_SPC,                  MO(3),   KC_RCTL,          KC_LEFT, 	KC_DOWN,	KC_RIGHT    , _______
	),
	[3] = LAYOUT(
		KC_GRV,	 KC_BRID,   KC_BRIU, 	 LCTL(KC_UP),   KC_Lpad, 	 _______,   _______, 	KC_MPRV, 	KC_MPLY, KC_MNXT,  KC_MUTE, 	KC_VOLD, 	 KC_VOLU  ,	KC_SHUTRGB,  KC_MUTE,
		_______,	KC_BLE1,	KC_BLE2, 	KC_BLE3, 	KC_24G, 	_______, 	_______, 	_______, 	_______, _______, 	_______, 	_______, 	_______, 	RGB_MOD,  _______,
		_______, 	_______, 	KC_WINMODE, 	_______, 	_______, 	_______,	_______, 	_______, 	_______, KC_LOCK, 	_______, 	_______, 	RGB_HUI,   KC_VAL_UP, 
	    _______, 	_______, 	_______,  	_______,   _______,	  _______, 	_______, 	_______, 	_______, 	_______, 	_______,    _______,   RGB_VAI,   KC_VAL_DN,
		_______, 	_______, 	_______,					KC_RESET,    	                      _______, 	KC_BAT,	RGB_SPD,	RGB_VAD, RGB_SPI  , _______
	),


	[4] = LAYOUT(
		KC_ESC,  KC_F1,    KC_F2,    KC_F3,    KC_F4,    KC_F5,    KC_F6,    KC_F7,    KC_F8,    KC_F9,    KC_F10,  	KC_F11,  	KC_F12,  	KC_BSPC,  KC_MUTE,
		KC_TAB,  KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P,    	KC_LBRC, 	KC_RBRC, 	KC_BSLS,KC_DELETE,
		KC_CAPS, KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN, 	KC_QUOT,    KC_ENT,     KC_PAGE_UP,
		KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    KC_COMM, KC_DOT,  KC_SLSH, 	KC_RSFT,    KC_UP,   KC_PAGE_DOWN,
		KC_LCTL, KC_LGUI,          KC_LALT,   KC_SPC,                  MO(5),   KC_RCTL,          KC_LEFT, 	KC_DOWN,	KC_RIGHT  , _______ 
	),
	[5] = LAYOUT(
		KC_GRV,	  KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0,	_______, 	 _______  ,	KC_SHUTRGB, KC_MUTE,
		_______, KC_BLE1, KC_BLE2, 	KC_BLE3, KC_24G,  _______, _______, 	_______, _______, _______, 	_______, 	_______, 	_______, 	RGB_MOD,     _______,
		_______, 	KC_MACMODE, 	_______, 	_______, 	_______, 	_______,	_______, 	_______, 	_______, KC_LOCK, 	_______, 	_______, 	RGB_HUI,   KC_VAL_UP, 
		_______, 	_______, 	_______,  	_______,   _______,	  _______, 	_______, 	_______, 	_______, 	_______, 	_______,    _______,   RGB_VAI,  KC_VAL_DN,
		_______, 	KC_WIN, 	_______,					KC_RESET,    	                      _______, 	KC_BAT,	RGB_SPD,	RGB_VAD, RGB_SPI  , _______
	),
	[6] = LAYOUT(
		KC_ESC,  KC_F1,    KC_F2,    KC_F3,    KC_F4,    KC_F5,    KC_F6,    KC_F7,    KC_F8,    KC_F9,    KC_F10,  	KC_F11,  	KC_F12,   	KC_BSPC, KC_MUTE,
		KC_TAB,  KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P,    	KC_LBRC, 	KC_RBRC, 	KC_BSLS,KC_DELETE,
		KC_CAPS, KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L,    KC_SCLN, 	KC_QUOT,    KC_ENT,     KC_PAGE_UP,
		KC_LSFT, KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M,    KC_COMM, KC_DOT,  KC_SLSH, 	KC_RSFT,    KC_UP,   KC_PAGE_DOWN,
		KC_LCTL, KC_LALT,          KC_LGUI,   KC_SPC,                  MO(7),   KC_RCTL,          KC_LEFT, 	KC_DOWN,	KC_RIGHT    , _______
	),
	[7] = LAYOUT(
		KC_GRV,	    KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0,	_______, 	 _______  ,	KC_SHUTRGB,  KC_MUTE,
		_______,	KC_BLE1,	KC_BLE2, 	KC_BLE3, 	KC_24G, 	_______, 	_______, 	_______, 	_______, _______, 	_______, 	_______, 	_______, 	RGB_MOD,  _______,
		_______, 	_______, 	KC_WINMODE, 	_______, 	_______, 	_______,	_______, 	_______, 	_______, KC_LOCK, 	_______, 	_______, 	RGB_HUI,   KC_VAL_UP, 
	    _______, 	_______, 	_______,  	_______,   _______,	  _______, 	_______, 	_______, 	_______, 	_______, 	_______,    _______,   RGB_VAI,   KC_VAL_DN,
		_______, 	_______, 	_______,					KC_RESET,    	                      _______, 	KC_BAT,	RGB_SPD,	RGB_VAD, RGB_SPI  , _______
	)
};
						

