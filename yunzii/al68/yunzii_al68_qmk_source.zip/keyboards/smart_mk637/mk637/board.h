#pragma once

#include_next <board.h>

#undef STM32F103xB
#define STM32F103xE